import React, { useEffect, useRef } from "react";
import io from "socket.io-client";
import * as mediasoupClient from "mediasoup-client";

const socket = io("http://localhost:3001");

const Viewer = () => {
  const videoRef = useRef();

  useEffect(() => {
    (async () => {
      const rtpCapabilities = await new Promise(resolve => {
        socket.emit("getRouterRtpCapabilities", null, resolve);
      });

      const device = new mediasoupClient.Device();
      await device.load({ routerRtpCapabilities: rtpCapabilities });

      const data = await new Promise(resolve => {
        socket.emit("createViewerTransport", null, resolve);
      });

      const transport = device.createRecvTransport(data);

      transport.on("connect", ({ dtlsParameters }, callback) => {
        socket.emit("connectViewerTransport", { dtlsParameters });
        callback();
      });

      const { kind, rtpParameters } = await new Promise(resolve => {
        socket.emit("consume", { rtpCapabilities }, resolve);
      });

      const consumer = await transport.consume({
        id: "video",
        producerId: "broadcaster",
        kind,
        rtpParameters
      });

      const stream = new MediaStream();
      stream.addTrack(consumer.track);
      videoRef.current.srcObject = stream;
    })();
  }, []);

  return <video ref={videoRef} autoPlay controls style={{ width: "100%" }} />;
};

export default Viewer;