import React, { useEffect } from "react";
import io from "socket.io-client";
import * as mediasoupClient from "mediasoup-client";

const socket = io("http://localhost:3001");

const Broadcaster = () => {
  useEffect(() => {
    (async () => {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      const video = document.querySelector("video");
      video.srcObject = stream;

      const rtpCapabilities = await new Promise(resolve => {
        socket.emit("getRouterRtpCapabilities", null, resolve);
      });

      const device = new mediasoupClient.Device();
      await device.load({ routerRtpCapabilities: rtpCapabilities });

      const data = await new Promise(resolve => {
        socket.emit("createBroadcasterTransport", null, resolve);
      });

      const transport = device.createSendTransport(data);

      transport.on("connect", ({ dtlsParameters }, callback) => {
        socket.emit("connectBroadcasterTransport", { dtlsParameters });
        callback();
      });

      transport.on("produce", async ({ kind, rtpParameters }, callback) => {
        socket.emit("produce", { kind, rtpParameters }, ({ id }) => {
          callback({ id });
        });
      });

      const track = stream.getVideoTracks()[0];
      await transport.produce({ track });
    })();
  }, []);

  return <video autoPlay muted style={{ width: "100%" }} />;
};

export default Broadcaster;