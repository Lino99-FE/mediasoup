const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const mediasoup = require("mediasoup");
const config = require("./mediasoup-config");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

let worker, router, broadcasterTransport, producer;
let viewerTransports = new Map();

(async () => {
  worker = await mediasoup.createWorker(config.mediasoup.worker);
  router = await worker.createRouter({ mediaCodecs: config.mediasoup.router.mediaCodecs });

  io.on("connection", (socket) => {
    console.log("Client connected:", socket.id);

    socket.on("getRouterRtpCapabilities", (_, cb) => {
      cb(router.rtpCapabilities);
    });

    socket.on("createBroadcasterTransport", async (_, cb) => {
      const transport = await router.createWebRtcTransport(config.mediasoup.webRtcTransport);
      broadcasterTransport = transport;
      cb({
        id: transport.id,
        iceParameters: transport.iceParameters,
        iceCandidates: transport.iceCandidates,
        dtlsParameters: transport.dtlsParameters,
      });
    });

    socket.on("connectBroadcasterTransport", async ({ dtlsParameters }) => {
      await broadcasterTransport.connect({ dtlsParameters });
    });

    socket.on("produce", async ({ kind, rtpParameters }, cb) => {
      producer = await broadcasterTransport.produce({ kind, rtpParameters });
      cb({ id: producer.id });
    });

    socket.on("createViewerTransport", async (_, cb) => {
      const transport = await router.createWebRtcTransport(config.mediasoup.webRtcTransport);
      viewerTransports.set(socket.id, transport);
      cb({
        id: transport.id,
        iceParameters: transport.iceParameters,
        iceCandidates: transport.iceCandidates,
        dtlsParameters: transport.dtlsParameters,
      });
    });

    socket.on("connectViewerTransport", async ({ dtlsParameters }) => {
      const transport = viewerTransports.get(socket.id);
      if (transport) await transport.connect({ dtlsParameters });
    });

    socket.on("consume", async ({ rtpCapabilities }, cb) => {
      if (!router.canConsume({ producerId: producer.id, rtpCapabilities })) {
        return cb({ error: "Cannot consume" });
      }

      const transport = viewerTransports.get(socket.id);
      const consumer = await transport.consume({
        producerId: producer.id,
        rtpCapabilities,
        paused: false,
      });

      cb({
        id: consumer.id,
        kind: consumer.kind,
        rtpParameters: consumer.rtpParameters,
      });
    });

    socket.on("disconnect", () => {
      viewerTransports.delete(socket.id);
    });
  });

  server.listen(3001, () => {
    console.log("Server running on http://localhost:3001");
  });
})();